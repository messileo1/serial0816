#include "ros/ros.h"
#include "std_msgs/String.h"

void mesg2333_callback(const std_msgs::String::ConstPtr &msg_p)//订阅到的消息是std_msgs::string类型，这个函数的参数类型是它的常量指针的引用
{
    //通过msg获取订阅到的消息，并对它进行处理,即在终端中打印出来
    ROS_INFO("serial_subscriber订阅的消息是:%s",msg_p->data.c_str());
}

int main(int argc, char *argv[])
{
    setlocale(LC_CTYPE, "zh_CN.utf8"); //设置编码，防止中文乱码

    //初始化节点名为：serial_subscriber
    ros::init(argc,argv,"serial_subscriber"); 
    //创建句柄seuNB666，用来管理资源
    ros::NodeHandle seuNB666;

    //用Subscriber类，实例化一个发布者对象，发布一个名为"Serial_Topic"的话题，话题的消息类型为std_msgs::String，消息发布队列长度为10(注意话题名中间不能有空格)
    ros::Subscriber yao666 = seuNB666.subscribe<std_msgs::String>("Serial_Topic",10,mesg2333_callback); //订阅的话题名，队列长度，回调函数

    //循环读取接收的数据，并调用回调函数处理：mesg2333_callback()每订阅到一次消息都需要执行一次，为了让回调函数多次执行，需要再执行完一次之后需要回头
    ros::spin(); 

    return 0;
}


